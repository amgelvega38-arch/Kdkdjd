# Cambio FF MORMAL / HOLO AR

- Se agregó la pestaña `FF MORMAL` al extremo derecho de las opciones del menú externo.
- Al seleccionarla aparece una sola opción: `HOLO AR`.
- `HOLO AR` usa el paquete `HOLO AR.3105` proporcionado y el mismo flujo de aplicar/restaurar, indicador de carga y estado que los demás paquetes.
- El paquete queda incluido en `ThreeOneOSFive/ProtectedPackages` y registrado como recurso del proyecto Xcode.

La integración se verificó estructuralmente y el paquete `.3105` se pudo leer y autenticar. No se ejecutó una compilación de Xcode ni se probó en un iPhone; la aplicación real depende de la compatibilidad del dispositivo y de los permisos requeridos por el proyecto.
